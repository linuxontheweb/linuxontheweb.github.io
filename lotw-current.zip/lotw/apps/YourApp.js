
export const app = function(Win, Desk) {

//Win.main._bgcol='#fff';
//Win.main._tcol="#CCC";
Win.main.innerHTML='<center><h1>Your awesome app goes here!</h1></center>';

}

