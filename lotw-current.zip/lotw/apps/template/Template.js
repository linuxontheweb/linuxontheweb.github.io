//Imports«
import { util, api as capi } from "util";
import {globals} from "config";

const{ log, cwarn, cerr, isnum, make, mkdv} = util;
//»

export const app = function(Win, Desk) {

//Var«

let Main = Win.main;

//»


//Funcs«


//»


this.onresize=resize;
this.onappinit=()=>{//«
}//»
this.onkill=()=>{//«
};//»
this.onkeydown=(e,k)=>{//«
};//»

}
