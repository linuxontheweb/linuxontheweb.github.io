echo "Hello world!"
echo "Listing for the current directory:"
ls

